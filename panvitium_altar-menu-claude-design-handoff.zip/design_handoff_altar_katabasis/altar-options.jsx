/* altar-options.jsx — three redesigns of the Katabasis altar drop-target.
   Each <AltarFrame> reproduces the real gate chrome (kicker → KATABASIS →
   verse → CTA) and swaps the central "lay your work upon the stone" target. */
const { useMemo, useState, useRef, useLayoutEffect } = React;

// ── ambient embers (matches the real AmbientEmbers) ──────────────────
function Embers({ n = 20, seed = 1 }) {
  const seeds = useMemo(() => {
    let s = seed * 9301 + 49297;
    const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    return Array.from({ length: n }, () => ({
      left: rnd() * 100,
      delay: rnd() * 9,
      dur: 7 + rnd() * 7,
      size: 1.5 + rnd() * 2.5,
      drift: (rnd() * 2 - 1) * 40,
    }));
  }, [n, seed]);
  return (
    <div className="embers" aria-hidden="true">
      {seeds.map((e, i) => (
        <span key={i} className="ember" style={{
          left: e.left + '%', width: e.size, height: e.size,
          '--drift': e.drift + 'px',
          animation: `rise ${e.dur}s ease-in ${e.delay}s infinite`,
        }} />
      ))}
    </div>
  );
}

// ── shared gate shell ────────────────────────────────────────────────
function AltarFrame({ seed, children, hint, actions, overlay, showCta = true }) {
  return (
    <div className="gate">
      <div className="fog" aria-hidden="true" />
      <Embers seed={seed} />
      <div className="inner">
        <h1 className="title">Katabasis</h1>
        {children}
        {hint && <div className="hint">{hint}</div>}
        {actions ? actions : (
          <>
            {showCta && <button className="cta" type="button">Lay upon the altar</button>}
            <button className="turn-away" type="button">Turn away — climb back to the altar room</button>
          </>
        )}
      </div>
      {overlay}
    </div>
  );
}

const SEAL = 'assets/sealBael.png';
const SEAL_PANVITIUM = 'assets/sealPanvitium.png';

// ── OPTION 1 — Carved Mensa (uses the altar relief skin) ─────────────
function OptionMensa() {
  return (
    <AltarFrame seed={3} hint="Lay your work upon the carved stone">
      <div className="t1-stage">
        <div className="t1-slab">
          <div className="t1-glow" aria-hidden="true" />
          <img className="t1-seal" src={SEAL} alt="" draggable="false" />
          <div className="t1-band">descend by the lesser key</div>
          <div className="t1-rim" aria-hidden="true" />
        </div>
      </div>
    </AltarFrame>
  );
}

// ── OPTION 2 — Seal Circle (no box; ritual circle of ember light) ────
// Build a ring string that contains ONLY whole phrases. Whatever arc is left
// over after fitting as many complete phrases as possible is padded with
// centred middle-dots, so a phrase is never clipped at the wrap seam.
const RING_PHRASE = 'PER VITIA, AD SOLIUM';
const RING_RADIUS = 118; // matches #ringPath

function OptionCircle() {
  const svgRef = useRef(null);
  // n = whole phrases evenly spaced around the ring.
  const [layout, setLayout] = useState({ n: 2 });
  // turn-away cinematic: fade the seal out and the altar room in.
  const [leaving, setLeaving] = useState(false);

  useLayoutEffect(() => {
    let cancelled = false;
    const build = () => {
      const svg = svgRef.current;
      if (!svg || cancelled) return;
      const NS = 'http://www.w3.org/2000/svg';
      const measure = (s) => {
        const t = document.createElementNS(NS, 'text');
        t.setAttribute('class', 't2-text');
        t.style.visibility = 'hidden';
        t.textContent = s;
        svg.appendChild(t);
        const len = t.getComputedTextLength();
        svg.removeChild(t);
        return len;
      };
      const C = 2 * Math.PI * RING_RADIUS;
      const phraseLen = measure(RING_PHRASE);
      const dotUnit = measure('\u00B7 '); // one middot + space
      if (!phraseLen || !dotUnit) return;
      const n = Math.max(1, Math.floor(C / (phraseLen + 4 * dotUnit)));
      if (!cancelled) setLayout({ n });
    };
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(build);
    build();
    return () => { cancelled = true; };
  }, []);

  const ticks = Array.from({ length: 48 }, (_, i) => {
    const a = (i / 48) * Math.PI * 2;
    const r1 = 150, r2 = i % 4 === 0 ? 138 : 144;
    return (
      <line key={i} className="t2-tick"
        x1={190 + Math.cos(a) * r1} y1={190 + Math.sin(a) * r1}
        x2={190 + Math.cos(a) * r2} y2={190 + Math.sin(a) * r2}
        strokeWidth={i % 4 === 0 ? 1.4 : 0.7} />
    );
  });

  // Whole phrases, centred at evenly-spaced fractions of the ring with blank
  // arcs between them. Fraction-based positions keep the spacing even by
  // construction, regardless of text measurement.
  const { n } = layout;
  const phrases = Array.from({ length: n }, (_, i) => (
    <text key={'p' + i} className="t2-text" textAnchor="middle">
      <textPath href="#ringPath" startOffset={((i + 0.5) / n) * 100 + '%'}>{RING_PHRASE}</textPath>
    </text>
  ));

  return (
    <AltarFrame
      seed={7}
      showCta={false}
      hint="Press the seal to begin the descent"
      actions={
        <div className="altar-actions">
          <button className="altar-action" type="button" onClick={() => setLeaving(true)}>
            <span className="altar-action-label">Turn away</span>
            <span className="altar-action-sub">climb back to the altar room</span>
          </button>
          <a className="altar-action" href="Status Quo.html">
            <span className="altar-action-label">Status quo</span>
            <span className="altar-action-sub">the ledger of Devotion</span>
          </a>
        </div>
      }
      overlay={
        <div className={'altar-room' + (leaving ? ' is-open' : '')} aria-hidden={!leaving}>
          <div className="altar-room-scene">
            <div className="altar-room-glow" />
            <img className="altar-room-relief" src="assets/altar.png" alt="" draggable="false" />
          </div>
          <div className="altar-room-label">The Altar Room</div>
          <button className="altar-room-back" type="button" onClick={() => setLeaving(false)}>
            Return to the seal
          </button>
        </div>
      }
    >
      <div className="t2-wrap">
        <div className="t2-core" aria-hidden="true" />
        <svg className="t2-svg" viewBox="0 0 380 380" ref={svgRef}>
          <defs>
            <path id="ringPath" d="M 190,190 m -118,0 a 118,118 0 1,1 236,0 a 118,118 0 1,1 -236,0" />
          </defs>
          <circle className="t2-stroke" cx="190" cy="190" r="170" strokeWidth="1" opacity="0.5" />
          <g className="t2-ring-spin">
            <circle className="t2-stroke" cx="190" cy="190" r="150" strokeWidth="1.4" />
            {ticks}
          </g>
          <circle className="t2-stroke" cx="190" cy="190" r="132" strokeWidth="0.8" opacity="0.7" />
          <g className="t2-ring-spin-rev">
            {phrases}
          </g>
          <circle className="t2-stroke" cx="190" cy="190" r="92" strokeWidth="1.2" />
        </svg>
        <button className="t2-seal-btn" type="button" aria-label="Lay your work upon the altar and descend">
          <img className="t2-seal t2-seal-panvitium" src={SEAL_PANVITIUM} alt="" draggable="false" />
        </button>
      </div>
    </AltarFrame>
  );
}

// ── OPTION 3 — Abyss Oculus (stone-rimmed well into fire) ────────────
function OptionOculus() {
  const sparks = Array.from({ length: 14 }, (_, i) => ({
    left: 20 + (i * 37) % 60,
    delay: (i * 0.4) % 4,
    dur: 2.6 + (i % 5) * 0.5,
  }));
  return (
    <AltarFrame seed={11} hint="Let the soul go down into the dark">
      <div className="t3-wrap">
        <div className="t3-well" aria-hidden="true" />
        <div className="t3-sparks" aria-hidden="true">
          {sparks.map((s, i) => (
            <span key={i} className="t3-spark" style={{
              left: s.left + '%',
              animation: `t3rise ${s.dur}s ease-in ${s.delay}s infinite`,
            }} />
          ))}
        </div>
        <div className="t3-rim" aria-hidden="true" />
        <img className="t3-seal" src={SEAL} alt="" draggable="false" />
      </div>
    </AltarFrame>
  );
}

// ── canvas ───────────────────────────────────────────────────────────
function App() {
  return (
    <DesignCanvas>
      <DCSection id="altar" title="Altar Gate — Seal Circle"
        subtitle="Bind your work within the circle. No box, no candles.">
        <DCArtboard id="circle" label="Seal Circle — per vitia, ad solium" width={1360} height={764}>
          <OptionCircle />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
