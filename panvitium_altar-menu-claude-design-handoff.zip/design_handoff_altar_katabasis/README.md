# Handoff: Katabasis Altar Gate + Status Quo Ledger

## Overview
Two connected screens for the **Katabasis** flow in *Panvitium*:

1. **Altar Gate** (`Altar Menu Redesign.html`) — the full-screen commit gate where the player
   "lays their work upon the altar" to descend into Hell. This is a redesign of the previous
   floating-box-with-candles drop target. The new target is a **ritual seal circle**: a glowing
   Goetic sigil ringed by rotating Latin script, on a void background with ember atmosphere.
   The **sigil itself is the button** that triggers the descent. Two choices sit below it:
   **TURN AWAY** (returns to the altar room) and **STATUS QUO** (opens the ledger).

2. **Status Quo Ledger** (`Status Quo.html`) — "The Ledger": the player's current standing.
   Shows each Cardinal Sin's level and effects, plus the effects of every bound sigil.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the
intended look and behavior, **not** production code to paste in. The task is to **recreate these
designs inside Panvitium's existing web app** (`apps/web`, React + TypeScript) using its established
components, state selectors, and CSS conventions (`menus.css`). The real data already exists in
`packages/sim` and `packages/shared` (see **Data Sources** below) — wire the UI to those selectors
rather than to the hard-coded sample values in the prototype.

The prototype's `Altar Menu Redesign.html` wraps the gate in a **design-canvas** (pan/zoom
presentation shell) only so it could be reviewed in isolation. **Ignore the canvas chrome** —
the deliverable is the single `.gate` screen (the `OptionCircle` component in `altar-options.jsx`).
`design-canvas.jsx` is presentation scaffolding and should not be ported.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, motion, and interaction are all specified
here and in the source files. Recreate pixel-accurately with the codebase's libraries. The only
stand-in is the **bound-sigil seal artwork** — per design direction the ledger lists sigil
**effects only** (no names, no seal images).

---

## Screens / Views

### 1. Altar Gate — Seal Circle
**Purpose:** The player commits to a Katabasis (descent). Pressing the seal begins it.

**Layout** (the `.gate` element):
- Fixed stage, design size **1360 × 764** (the live game should make this fill the viewport;
  the prototype letterboxes it inside the canvas). Flex column, centered, text-centered.
- Vertical order, centered: **title** → **seal circle** → **hint** → **two action gates**.
- Background: layered radial gradients (blood-red glow rising from the bottom, dark vignette at
  top) over near-black `#07050a`. A screen-blend **fog** layer pulses (5s) and **ember** particles
  rise from the bottom (see Interactions).

**Components:**

- **Title "Katabasis"**
  - Font: Cinzel 700, **4.4rem**, `letter-spacing: .22em`, `text-transform: uppercase`,
    `padding-left: .22em` (optical balance for the tracking).
  - Color `#efe2da`; `text-shadow: 0 0 40px rgba(140,24,22,.7), 0 0 12px rgba(255,90,60,.3), 0 2px 6px #000`.

- **Seal circle** (`.t2-wrap`, 380 × 380):
  - Soft ember **core glow** behind it (`.t2-core`, 280×280 radial, blurred, pulsing 4s).
  - An **SVG ring** (`viewBox 0 0 380 380`) containing, all stroked in `rgba(255,90,50,.55)`:
    - outer circle r=170 (opacity .5), ring r=150 with **48 tick marks** (every 4th longer/thicker),
      circle r=132 (opacity .7), inner circle r=92.
    - The tick group rotates **clockwise, 60s linear infinite**; the text group rotates
      **counter-clockwise, 90s**.
    - **Ring text:** the phrase **“PER VITIA, AD SOLIUM”** placed as whole phrases at evenly spaced
      fractions of the ring (currently 2, opposite each other), centered on each fraction via
      `textPath` + `text-anchor:middle`. **Gaps are blank** (no dots/filler). Font: IM Fell English
      SC, 15px, `letter-spacing: 6px`, uppercase, fill `rgba(255,150,110,.78)`. The count of phrases
      is computed from measured text width so phrases are never clipped at the seam — see
      `OptionCircle` `useLayoutEffect`.
  - **Center sigil** = the button (`.t2-seal-btn` wrapping `<img>` `assets/sealPanvitium.png`,
    width **152px**). Ember drop-shadow glow, gentle opacity/glow pulse (`@keyframes t2seal`, 3.8s).

- **Hint** (`.hint`): “Press the seal to begin the descent.” IM Fell English SC italic, .92rem,
  color `--faint` `#6a635c`, `margin-top: 1.5rem`.

- **Two action gates** (`.altar-actions`, flex row, `gap:14px`, `margin-top:1.6rem`):
  Each `.altar-action` is a two-line panel, `min-width:220px`, `padding:.85rem 1.8rem`,
  `border:1px solid rgba(160,30,34,.35)`, `border-radius:5px`,
  background `linear-gradient(rgba(40,18,16,.4), rgba(18,8,8,.5))`.
  - **Label** (`.altar-action-label`): Cinzel, .95rem, `letter-spacing:.16em`, uppercase, `#ffd9cf`.
  - **Sub** (`.altar-action-sub`): IM Fell English SC italic, .76rem, `--faint`.
  - **TURN AWAY** — sub "climb back to the altar room". Triggers the altar-room transition.
  - **STATUS QUO** — sub "the ledger of Devotion". Navigates to the ledger screen.
  - Hover: background darkens/reddens, `border-color:#a01e22`, `box-shadow:0 0 26px rgba(160,30,34,.32)`.
  - Active: `transform: scale(.985)`.

### 1b. Altar Room (TURN AWAY transition)
**Purpose:** Visual exit from the gate back to the altar room scene.

- `.altar-room` overlay covers the gate (`position:absolute; inset:0; z-index:8`), fades in over
  **1.1s** (`opacity 0→1`), `pointer-events` enabled only when open.
- Background: blood glow at bottom + dark vignette over `#050307`.
- A dim **carved altar relief** (`assets/altar.png`, width 520, `brightness(.7)`, masked top &
  bottom to fade) sits at the bottom with a pulsing ember glow behind it.
- Label **"The Altar Room"** (Cinzel 600, 2.4rem, `letter-spacing:.26em`, uppercase, `#efe2da`).
- **"Return to the seal"** button (IM Fell English SC, uppercase, .76rem, underlined on hover)
  closes the overlay.
- *In the real game this should route to the actual Altar Room scene rather than an in-screen overlay.*

### 2. Status Quo — The Ledger
**Purpose:** Show the player's current standing: Cardinal Sin levels + effects, and bound-sigil effects.

**Layout:** Scrolling document, `.wrap` `max-width:1120px`, centered, `padding:56px 40px 80px`.
Background matches the gate (radial ember/vignette over `#07050a`) plus a very faint (5% opacity)
altar-relief texture fading from the top. **Scrollbar is hidden** (`scrollbar-width:none` +
`::-webkit-scrollbar{display:none}`) — scrolling still works.

**Components, top to bottom:**

- **Back link** (`.back`): “← Return to the altar”. IM Fell English SC, uppercase, .76rem, `--faint`,
  hover `--bone`. Routes to the Altar Gate.
- **Masthead** (centered):
  - eyebrow “STATUS QUO” (IM Fell English SC, `letter-spacing:.42em`, uppercase, .78rem, `--faint`).
  - h1 “The Ledger” (Cinzel 700, 3.1rem, `letter-spacing:.2em`, uppercase, `#efe2da`, ember shadow).
  - dek (IM Fell English SC italic, 1.05rem, `--dim`, `max-width:56ch`).
- **Summary strip** (`.summary`, max-width 760, top+bottom hairline rules `rgba(160,30,34,.22)`):
  three centered stats separated by thin vertical rules — **Total Devotion**, **Princes Seated**
  (`n / 8`), **Sigils Bound**. Numbers: Cinzel 600, 1.7rem, `#f0d9b0`. Labels: IM Fell English SC,
  uppercase, .68rem, `--faint`.
- **Section heading** pattern (`.section-head`): Cinzel 600, 1.15rem, `letter-spacing:.22em`,
  uppercase `#e7d6c2`, followed by a `linear-gradient` rule that fades out, and a right-aligned
  caption in IM Fell English SC `--faint`.
- **Cardinal Sins** — `.sins` grid, **2 columns**, `gap:14px`. Each `.sin` card:
  - `padding:18px 20px`, bg `linear-gradient(rgba(28,16,18,.5), rgba(14,8,9,.55))`,
    `border:1px solid rgba(120,40,40,.26)`, `border-radius:6px`.
  - A 3px **left accent bar** (ember→blood gradient, opacity .55). For **level-0 (dormant)** sins the
    bar is faint grey and the level-effect row is dimmed/italic.
  - Top row: **Latin name** (Cinzel 600, 1.25rem, `#f0e4d8`) + **English** (IM Fell English SC italic,
    .92rem, `--dim`), with **pips** right-aligned: `●`/`○` (filled = ember `#ff5a3a`, empty
    `rgba(143,135,128,.4)`), 4 total = `MAX_SIN_LEVEL`.
  - Prince line: “{Prince} · *{epithet}*” (IM Fell English SC, .82rem, `--faint`).
  - Two **effect rows** (`.eff`, grid `92px 1fr`): a small uppercase tag + text.
    - **SKILL** tag (ember): “{skillName} — {skillEffect}”.
    - **LEVEL {n}** tag (gold `#d9b25a`): the `levelEffect` text.
- **Bound Sigils** — `.sigils` grid, **2 columns**, `gap:12px 28px`. Each `.sigil` row:
  - left: **effect** text (EB Garamond, 1.04rem, `--bone`, `white-space:nowrap`) with a colored
    **direction arrow** `↑`/`↓` (ember).
  - right: “**{souls}** souls” (IM Fell English SC, .82rem, `--faint`, count in gold).
  - hairline bottom border `rgba(120,40,40,.18)`.
  - **No seal names, no seal images** — effects only (deliberate).
- **Note** (`.sigils-note`, IM Fell English SC italic, `--faint`): “A sigil shows here only once
  enough souls are bound for it to bite.”

---

## Interactions & Behavior
- **Press the seal** (`.t2-seal-btn`): hover `scale(1.06)` + brighter ember glow; active `scale(.95)`
  (`transition .28s cubic-bezier(.2,.7,.3,1)`). This is the descend trigger — wire to the
  real Katabasis commit (the old design used an arm→confirm two-tap; confirm with product whether
  to keep that safeguard on the seal press).
- **TURN AWAY**: opens the altar-room overlay (1.1s fade). In-game, route to the Altar Room scene.
- **STATUS QUO** / **Back link**: navigation between the two screens.
- **Ring rotation**: continuous, opposite directions (60s / 90s linear), `prefers-reduced-motion`
  should disable these and the pulses in the real build.
- **Ambient embers**: ~20 particles rising bottom→top over 7–14s with horizontal drift; deterministic
  seed so layout is stable (see `Embers` in `altar-options.jsx`). Matches the existing `AmbientEmbers`.

## State Management
- **Altar Gate:** `leaving` boolean (altar-room overlay). The seal press dispatches the descent action.
- **Status Quo:** read-only view. Needs:
  - per-Sin **level** (`sinLevel(state.devotion[key])`) and **devotion total** (formatted),
  - **bound sigils** = `state.sigilBindings` entries with souls > 0 (effects only),
  - derived summary: total devotion, count of sins at level ≥ 1, count of bound sigils.

## Data Sources (already in the codebase — do NOT hard-code)
- **Sins:** `packages/shared/src/strings.ts` → `strings.sins[key]` gives `prince, latin, english,
  epithet, skill, skillEffect, levelEffect`. Order/levels via `SINS` + `sinLevel` in `packages/sim`.
  `buildAltar(state)` in `apps/web/src/game/altar.ts` already assembles the sins + bound-sigils view.
- **Pips / max level:** `MAX_SIN_LEVEL = 4` and `pips(level)` in `apps/web/src/menus/menus.data.ts`.
- **Sigil effects:** `SIGILS` (`{ n, name, desc }`) — use **`desc`** as the effect string; omit `name`.
- The hard-coded arrays in `status-quo.jsx` are sample values for the prototype only.

## Design Tokens
```
Colors
  --void     #07050a   page background base
  --ash      #c9c4bc   body text
  --bone     #d6cfc6   bright text
  --dim      #8f8780   secondary text
  --faint    #6a635c   tertiary / labels
  --ember    #ff5a3a   primary glow / active pips / accents
  --ember-soft #ff7a4a
  --blood    #a01e22   borders, deep glow
  --gold     #d9b25a   numbers, LEVEL tag

Typography
  Display    'Cinzel' (500/600/700)            titles, names, numbers, buttons
  Inscribe   'IM Fell English SC'              eyebrows, labels, hints, ring text (italic for lore)
  Body       'EB Garamond' (0/italic)          paragraphs, sigil effect text

Radius      5px (buttons/panels), 6px (cards)
Spacing     card padding 18px/20px; grid gaps 12–14px; section gaps ~52–60px
Motion      seal hover .28s cubic-bezier(.2,.7,.3,1); overlay fade 1.1s;
            ring spin 60s/90s linear; ember rise 7–14s; pulses 3.6–4s ease-in-out
```

## Assets
- `assets/altar.png` — carved stone-relief texture (used for the altar-room scene and a faint
  ledger background). Provided by the user; lives in-game at `apps/web/public/assets/panvitium/`.
- `assets/sealPanvitium.png` — the central Goetic three-trident sigil, extracted from the user's
  reference and recolored to bone/ember line-art on transparency. This is the descend button glyph.
- **Bound-sigil seal art is intentionally NOT used** on the ledger (effects only).
- Fonts via Google Fonts (Cinzel, IM Fell English SC, EB Garamond) — swap to the codebase's font
  loading if it self-hosts.

## Files
```
Altar Menu Redesign.html   gate screen host (loads React + Babel + the JSX below)
altar-options.jsx          OptionCircle = the seal-circle gate (port THIS); AltarFrame chrome;
                           Embers; also Option 1/3 explorations (not chosen — ignore)
Status Quo.html            ledger host
status-quo.jsx             ledger view + sample data + Pips/SinCard components
design-canvas.jsx          review-only pan/zoom shell — DO NOT port
assets/altar.png, assets/sealPanvitium.png
screenshots/               reference renders (see below)
```

## Screenshots (in `screenshots/`)
- `altar-seal-gate.png` — the Altar Gate (seal circle + two action gates).
- `altar-room-turn-away.png` — the TURN AWAY altar-room transition.
- `status-quo-top.png` — ledger masthead, summary strip, Cardinal Sins grid.
- `status-quo-bottom.png` — remaining sins + Bound Sigils (effects only).
