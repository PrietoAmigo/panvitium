/* status-quo.jsx — "The Ledger of Devotion": current Cardinal Sin levels with
   their skill + per-level effects, and the effects of bound sigils (effects only,
   no seal names or art). Data mirrors the game's authoritative catalog. */

const MAX_SIN_LEVEL = 4;

// Cardinal Sins — prince/epithet/skill/level effects from strings.sins; levels &
// devotion from the live ledger.
const SINS = [
  { latin: 'Superbia', english: 'Pride', prince: 'Lucifer', epithet: 'The Light-Bringer',
    skill: 'Morning Star', skillEffect: 'Increases overall Stellar outcomes.',
    levelEffect: 'Each level keeps more maleficia on descent.', level: 3, devotion: '4.21K' },
  { latin: 'Avaritia', english: 'Greed', prince: 'Mammon', epithet: 'The Hoarder Below',
    skill: 'Golden Hand', skillEffect: 'Increases overall gold gain rate.',
    levelEffect: 'Each level keeps more gold on descent.', level: 3, devotion: '3.88K' },
  { latin: 'Luxuria', english: 'Lust', prince: 'Asmodeus', epithet: 'King of the Nine Hells',
    skill: 'Seduction', skillEffect: 'Increases overall reprobate generation rate.',
    levelEffect: 'Each level keeps more reprobates on descent.', level: 2, devotion: '1.94K' },
  { latin: 'Ira', english: 'Wrath', prince: 'Satan', epithet: 'The Adversary',
    skill: 'Retribution', skillEffect: 'Increases Decimatio success and action efficiency.',
    levelEffect: 'Each level raises acolyte and invocation efficiency.', level: 2, devotion: '1.50K' },
  { latin: 'Gula', english: 'Gluttony', prince: 'Beelzebub', epithet: 'Lord of the Flies',
    skill: 'Insatiability', skillEffect: 'Decreases overall Terrible and Apocalyptic outcomes.',
    levelEffect: 'Each level raises your online action efficiency.', level: 2, devotion: '1.12K' },
  { latin: 'Tristitia', english: 'Sorrow', prince: 'Leviathan', epithet: 'The Coiled Deep',
    skill: 'Resignation', skillEffect: 'Increases Suasio success and action efficiency.',
    levelEffect: 'Each level raises the base reprobate suicide chance.', level: 1, devotion: '640' },
  { latin: 'Acedia', english: 'Sloth', prince: 'Belphegor', epithet: 'The Idle Throne',
    skill: 'Procrastination', skillEffect: 'Increases offline generation, gold and efficiency.',
    levelEffect: 'Each level compounds your offline time.', level: 1, devotion: '590' },
  { latin: 'Vanagloria', english: 'Vainglory', prince: 'Rosier', epithet: 'The Fair Tongue',
    skill: 'Acclaim', skillEffect: 'Increases maximum influence.',
    levelEffect: 'Each level raises your influence gain rate.', level: 0, devotion: '120' },
];

// Bound sigils — EFFECTS ONLY (no names, no seals), with souls bound into each.
const BOUND_SIGILS = [
  { effect: 'Influence gain', dir: '\u2191', bound: '2.10K' },
  { effect: 'Gold gain', dir: '\u2191', bound: '1.74K' },
  { effect: 'Reprobate generation', dir: '\u2191', bound: '980' },
  { effect: 'Acolyte efficiency', dir: '\u2191', bound: '640' },
  { effect: 'Decimatio efficiency', dir: '\u2191', bound: '410' },
  { effect: 'Apocalyptic chance', dir: '\u2193', bound: '300' },
  { effect: 'Suasio efficiency', dir: '\u2191', bound: '250' },
  { effect: 'Maximum influence', dir: '\u2191', bound: '180' },
];

function Pips({ level }) {
  return (
    <span className="pips">
      {Array.from({ length: MAX_SIN_LEVEL }, (_, i) => (
        <span key={i} className={i < level ? 'on' : 'off'}>{i < level ? '\u25CF' : '\u25CB'}</span>
      ))}
    </span>
  );
}

function SinCard({ sin }) {
  const dormant = sin.level === 0;
  return (
    <div className={'sin' + (dormant ? ' dormant' : '')}>
      <div className="sin-top">
        <div className="sin-name">
          <span className="sin-latin">{sin.latin}</span>
          <span className="sin-eng">{sin.english}</span>
        </div>
        <Pips level={sin.level} />
      </div>
      <div className="sin-prince">{sin.prince} · <span className="epithet">{sin.epithet}</span></div>
      <div className="sin-effects">
        <div className="eff">
          <span className="tag">Skill</span>
          <span className="txt"><span className="skillname">{sin.skill}</span> — {sin.skillEffect}</span>
        </div>
        <div className="eff lvl">
          <span className="tag lvl">Level {sin.level}</span>
          <span className="txt">{sin.levelEffect}</span>
        </div>
      </div>
    </div>
  );
}

function App() {
  const seated = SINS.filter((s) => s.level >= 1).length;
  return (
    <div className="wrap">
      <a className="back" href="Altar Menu Redesign.html"><span className="arrow">&#8592;</span> Return to the altar</a>

      <div className="masthead">
        <div className="eyebrow">Status Quo</div>
        <h1>The Ledger</h1>
        <p className="dek">
          The Devotion owed each Prince and the rank it buys you, the powers your Sins now exert,
          and the effects of every sigil bound to your soul.
        </p>
      </div>

      <div className="summary">
        <div className="stat"><div className="num">14.0K</div><div className="lab">Total Devotion</div></div>
        <div className="stat"><div className="num">{seated} / 8</div><div className="lab">Princes Seated</div></div>
        <div className="stat"><div className="num">{BOUND_SIGILS.length}</div><div className="lab">Sigils Bound</div></div>
      </div>

      <div className="section-head">
        <h2>Cardinal Sins</h2>
        <div className="rule" />
        <div className="count">levels &amp; effects</div>
      </div>
      <div className="sins">
        {SINS.map((s) => <SinCard key={s.latin} sin={s} />)}
      </div>

      <div className="section-head">
        <h2>Bound Sigils</h2>
        <div className="rule" />
        <div className="count">effects only</div>
      </div>
      <div className="sigils">
        {BOUND_SIGILS.map((g, i) => (
          <div className="sigil" key={i}>
            <span className="effect">{g.effect} <span className="dir">{g.dir}</span></span>
            <span className="bound"><b>{g.bound}</b> souls</span>
          </div>
        ))}
      </div>
      <p className="sigils-note">A sigil shows here only once enough souls are bound for it to bite.</p>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
