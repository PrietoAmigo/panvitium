/* ars-goetia.data.ts — FIXTURE + design FLAVOUR for the Ars Goetia book.
   ----------------------------------------------------------------------------
   FLAVOUR (rank numeral, lore, illustration path) keyed by invocation id —
   reusable in production: merge it onto the sim roster in your buildGoetia
   adapter.  GOETIA_PREVIEW is a storybook fixture to render the book in
   isolation — DELETE / replace with real sim data on integration.

   ⚠️  ArsGoetiaBook must never import this file. Props in, callbacks out. */

import type { GoetiaEntry } from './ars-goetia.types.js';

export const ASSET_BASE = '/assets/panvitium';

/** FLAVOUR per invocation id, merged onto sim mechanics by buildGoetia(). */
export const GOETIA_FLAVOUR: Record<string, { rank: string; lore: string; illus: string }> = {
  imp: {
    rank: 'I',
    lore: 'A minor familiar, eager and spiteful. It scuttles where it is told and bites what it is shown.',
    illus: `${ASSET_BASE}/invocations/imp.png`,
  },
  upir: {
    rank: 'II',
    lore: 'A revenant that feeds in the dark and does not tire. It thins the herd cleanly, and asks only that you look away.',
    illus: `${ASSET_BASE}/invocations/upir.png`,
  },
  harpy: {
    rank: 'III',
    lore: 'She carries whispers between the living, and leaves each one heavier than she found it.',
    illus: `${ASSET_BASE}/invocations/harpy.png`,
  },
  fama: {
    rank: 'IV',
    lore: 'Rumour given a thousand mouths and wings to carry them. By the time it is denied, it is already believed.',
    illus: `${ASSET_BASE}/invocations/fama.png`,
  },
  nightmare: {
    rank: 'V',
    lore: 'It rides the sleeping and rides them down. The waking call it despair and never name the rider.',
    illus: `${ASSET_BASE}/invocations/nightmare.png`,
  },
  behemoth: {
    rank: 'VI',
    lore: 'The glutton-beast, first of the appetites. Where it treads, the ground is never sated and neither are they.',
    illus: `${ASSET_BASE}/invocations/behemoth.png`,
  },
};

/* ---- FIXTURE: a slice of the roster to preview the book in isolation.
   Replace with the real view-model (buildGoetia) on integration. ---- */
export const GOETIA_PREVIEW: GoetiaEntry[] = [
  {
    id: 'imp',
    name: 'Imp',
    rank: 'I',
    cost: 'No soul cost',
    effect: '+10% reprobate generation while bound.',
    lore: GOETIA_FLAVOUR.imp!.lore,
    illus: GOETIA_FLAVOUR.imp!.illus,
    unlocked: true,
  },
  {
    id: 'upir',
    name: 'Upir',
    rank: 'II',
    cost: '12 Souls',
    effect: '+25% Decimatio yield.',
    lore: GOETIA_FLAVOUR.upir!.lore,
    illus: GOETIA_FLAVOUR.upir!.illus,
    unlocked: true,
  },
  {
    id: 'harpy',
    name: 'Harpy',
    rank: 'III',
    cost: '40 Souls',
    effect: '+25% Suasio efficiency.',
    lore: GOETIA_FLAVOUR.harpy!.lore,
    illus: GOETIA_FLAVOUR.harpy!.illus,
    unlocked: true,
  },
  {
    id: 'nightmare',
    name: 'Nightmare',
    rank: 'V',
    cost: '14 invoking power',
    gate: 'Tristitia L2',
    effect: 'Raises the base suicide rate.',
    lore: GOETIA_FLAVOUR.nightmare!.lore,
    illus: GOETIA_FLAVOUR.nightmare!.illus,
    unlocked: false,
  },
  {
    id: 'behemoth',
    name: 'Behemoth',
    rank: 'VI',
    cost: '30 invoking power',
    gate: 'Gula L3',
    effect: '×2 reprobate generation.',
    lore: GOETIA_FLAVOUR.behemoth!.lore,
    illus: GOETIA_FLAVOUR.behemoth!.illus,
    unlocked: false,
  },
];
