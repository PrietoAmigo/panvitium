# Ars Goetia menu — changes only

A focused export of **just the Ars Goetia grimoire**, decoupled from the degradation layer so it can
be integrated on its own. No degradation-engine code, no new CSS, no new assets.

## Files → `apps/web/src/menus/`

| File | What it is |
| --- | --- |
| `ArsGoetiaBook.tsx` | The full-screen grimoire overlay. **Prop-driven** (replaces the prior version). |
| `ars-goetia.types.ts` | `GoetiaEntry` + `ArsGoetiaBookProps` — self-contained (no longer imports the degradation `types.ts`). |
| `ars-goetia.data.ts` | FLAVOUR (rank/lore/illus per id) + a preview fixture. The component never imports it. |

## What changed vs. the previous Ars Goetia

- **Now presentational + prop-driven.** It takes `entries`, `invokingPower`, and
  `onSummon` / `onDispel` / `onClose` — no store reads, no internal data catalog. The only local
  state is which entry leaf is open.
- **Types are self-contained.** Imports from `./ars-goetia.types.js` instead of the shared
  degradation `types.ts`, so this menu carries no dependency on the degradation layer.
- **Graceful fallbacks (strict-TS safe):** optional `gate` / `effect` / `lore` / `illus` are each
  guarded — an entry with no illustration renders a text plate ("No plate has been drawn for this
  seal."), an ungated entry hides the Gate row, and the index hint shows the effect (unlocked) or the
  gate label / "Sealed" (locked).
- **A11y:** `role="dialog"`, `aria-modal`, `aria-label="Ars Goetia"`; the close glyph button has an
  `aria-label`.

## Contract

```
Archetype:        full-screen overlay; renders its OWN shell (.goetia-overlay) + close; takes onClose
Props (data in):  entries: GoetiaEntry[]   — name/cost/gate/effect/unlocked REAL; rank/lore/illus FLAVOUR
                  invokingPower: string     — REAL, PRE-FORMATTED (no bignum math in the component)
Callbacks (out):  onSummon(id), onDispel(id), onClose()
Local UI state:   which entry leaf is open
IDs keyed by:     invocation id (imp, upir, harpy, fama, nightmare, behemoth, …)
Assets:           entry.illus under /assets/panvitium/invocations/…; missing → text plate fallback
CSS:              reuses existing .goetia-* / .gb-* classes — nothing new to add
```

## View-model seam (TODO(wire))

Feed `entries` from the existing `buildGoetia(state)` adapter: map each sim invocation onto
`GoetiaEntry` by id — `name/cost/gate/effect/unlocked` REAL (already formatted), `rank/lore/illus`
merged from `GOETIA_FLAVOUR` by id (`illus` omitted where no plate exists). `invokingPower` is the
pre-formatted current power. `onSummon`/`onDispel` call the store's `summon`/`banish`; `onClose`
closes the `ars-goetia` panel.

```tsx
import { ArsGoetiaBook } from './ArsGoetiaBook.js';
import { GOETIA_FLAVOUR } from './ars-goetia.data.js'; // FLAVOUR only
import type { GoetiaEntry } from './ars-goetia.types.js';

const entries: GoetiaEntry[] = roster.map((inv): GoetiaEntry => {
  const f = GOETIA_FLAVOUR[inv.id];
  return {
    id: inv.id,
    name: inv.name,
    rank: f?.rank ?? '·',
    cost: inv.costLabel,        // REAL, pre-formatted
    ...(inv.gateLabel ? { gate: inv.gateLabel } : {}),
    ...(inv.effectLabel ? { effect: inv.effectLabel } : {}),
    ...(f?.lore ? { lore: f.lore } : {}),
    ...(f?.illus ? { illus: f.illus } : {}),
    unlocked: inv.unlocked,
  };
});

<ArsGoetiaBook
  entries={entries}
  invokingPower={invokingPowerLabel}
  onSummon={summon}
  onDispel={banish}
  onClose={closePanel}
/>
```

> Optional props are spread conditionally (never passed `undefined`) to satisfy
> `exactOptionalPropertyTypes`. Relative imports carry `.js` per the repo's ESM/NodeNext config.
